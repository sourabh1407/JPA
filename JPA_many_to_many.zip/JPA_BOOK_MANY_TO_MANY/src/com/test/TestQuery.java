package com.test;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

public class TestQuery {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		
		TypedQuery<Book> bk=null;
		List<Book> list=null;
		
		String qryAll = "from Book";
		
		String qryBookAuthor ="from Book where author.authorName=?";
		
		String qryPriceRange="from Book where bookPrice between 500 and 1000";
		
		String qryAuthorName="from Book where bookId=?";
		
		System.out.println("Enter operation to perform : ");
		System.out.println("1. Query all books in database");
		System.out.println("2. Query all books written by an author");
		System.out.println("3. Query all books in given price range");
		System.out.println("4. Query all author name for a bookid");
		
		Scanner ip =new Scanner(System.in);
		
		Byte choice = Byte.parseByte(ip.next());
		ip.nextLine();
		
		switch (choice) {
		case 1:
			bk = em.createQuery(qryAll, Book.class);
			list = bk.getResultList();

			for(Book b : list)
			{	
				System.out.println(b.getBookId()+"\t"+b.getBookName()+"\t"+b.getBookPrice());
			}
			break;
		case 2:
			
			System.out.println("Enter author name");
			String authorName= ip.nextLine();
			bk= em.createQuery(qryBookAuthor, Book.class);
			bk.setParameter(1, authorName);
			list = bk.getResultList();
			for(Book b:list)
			{
				System.out.println(b.getBookName()+"\t"+b.getBookPrice());
			}
			break;
		case 3:
			bk = em.createQuery(qryPriceRange, Book.class);
			list = bk.getResultList();
			for(Book b:list)
			{
				System.out.println(b.getBookName()+"\t"+b.getBookPrice());
			}
			break;
		case 4:
			System.out.println("Enter bookId");
			int bookId = ip.nextInt();
			bk= em.createQuery(qryAuthorName, Book.class);
			bk.setParameter(1, bookId);
			list = bk.getResultList();
			
			break;

		default:
			System.out.println("Wrong input given");
			break;
		}
		
		ip.close();
		em.getTransaction().commit();
		em.close();
		emf.close();
	}

}
