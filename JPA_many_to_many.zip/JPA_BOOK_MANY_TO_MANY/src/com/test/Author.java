package com.test;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="authors_tbl_many_to_many")
public class Author {
	@Id
	@Column(name="authorId")
	private int authorId;
	
	@Column(name="authorName",length=25)
	private String authorName;
	
	@ManyToMany(cascade=CascadeType.ALL)
	@JoinTable(name="book_join_author",joinColumns={@JoinColumn(name="bookId")},inverseJoinColumns={@JoinColumn(name="authorId")})
	private Set<Book> book = new HashSet<Book>();

	public int getAuthorId() {
		return authorId;
	}

	public void setAuthorId(int authorId) {
		this.authorId = authorId;
	}

	public String getAuthorName() {
		return authorName;
	}

	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}

	public Set<Book> getBook() {
		return book;
	}

	public void setBook(Set<Book> book) {
		this.book = book;
	}

	public void addBooks(Book b)
	{
		this.getBook().add(b);
	}
	
	
	
}
