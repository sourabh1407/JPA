package com.test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class TestAddInfo {
	public static void main(String[] args) {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		
		Book b1 =new Book();
		b1.setBookId(1);
		b1.setBookName("Hello Java");
		b1.setBookPrice(750);
		
		Book b2 =new Book();
		b2.setBookId(2);
		b2.setBookName("The chronicles of Java");
		b2.setBookPrice(1550);
		
		Book b3 =new Book();
		b3.setBookId(3);
		b3.setBookName("Java - The complete Reference");
		b3.setBookPrice(2000);
		
		Author a1 = new Author();
		a1.setAuthorId(1);
		a1.setAuthorName("Sourabh");
		
		Author a2 = new Author();
		a2.setAuthorId(2);
		a2.setAuthorName("Rushi");
		
		Author a3 = new Author();
		a3.setAuthorId(3);
		a3.setAuthorName("Amrutha");
		
		b1.setAuthor(a1);
		b2.setAuthor(a2);
		b3.setAuthor(a3);
		
		em.persist(b1);
		System.out.println("Book and Author 1 added");
		em.persist(b2);
		System.out.println("Book and Author 2 added");
		em.persist(b3);
		System.out.println("Book and Author 3 added");
		
		em.getTransaction().commit();
		em.close();
		emf.close();
	}
}
