package com.cg.author.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.cg.author.entities.Author;
import com.cg.author.exception.AuthorException;

public class AuthorDAO implements IAuthorDAO {

	private EntityManager entityManager;

	public AuthorDAO() {
		entityManager = JPAUtil.getEntityManager();
	}
	
	@Override
	public int addAuthor(Author author) throws AuthorException {
		//to-do : add sequence to authorId
		entityManager.getTransaction().begin();		
		entityManager.persist(author);
		entityManager.getTransaction().commit();
		return author.getAuthorId();
	}

	@Override
	public Author deleteAuthor(int authorId) throws AuthorException {
		entityManager.getTransaction().begin();	
		Author author=entityManager.find(Author.class,authorId);
		if(author==null)
		{
			//System.out.println("Author not found");
			return null;
		}
		else
		{
			entityManager.remove(author);
			entityManager.getTransaction().commit();
			return author;
		}
		
	}

	@Override
	public Author findAuthor(int authorId) throws AuthorException {
		entityManager.getTransaction().begin();	
		Author author=entityManager.find(Author.class,authorId);
		if(author==null)
		{
			//System.out.println("Author not found");
			return null;
		}
		else
		{
			entityManager.getTransaction().commit();
			return author;
		}
	}

	@Override
	public List<Author> displayAll() throws AuthorException {
		entityManager.getTransaction().begin();	
		TypedQuery<Author> qry=entityManager.createNamedQuery("displayAll", Author.class);
		List<Author> list = qry.getResultList();
		entityManager.getTransaction().commit();
		if(list.isEmpty())
		{
		return null;
		}
		return list;
	}

	@Override
	public boolean updateAuthor(int authorId,String phoneNo) throws AuthorException {
		entityManager.getTransaction().begin();	
		Author emp=entityManager.find(Author.class,authorId);
		if(emp==null)
		{
			return false;
		}
		else
		{	
			emp.setPhoneNo(phoneNo);
			entityManager.merge(emp);
			entityManager.getTransaction().commit();
			
		}
		return true;
	}

}
