package com.cg.author.client;

import java.util.List;
import java.util.Scanner;

import com.cg.author.entities.Author;
import com.cg.author.exception.AuthorException;
import com.cg.author.service.AuthorService;
import com.cg.author.service.IAuthorService;

public class AuthorClient {
	
	public static void main(String[] args) {
		
		boolean isUpdated=false;
		byte choice = 0;
		
		String firstName = null;
		String middleName = null;
		String lastName = null;
		String phoneNo = null;
		int authorId=0;
		
		IAuthorService authorService = new AuthorService();
		
		Author author = null;
		
		List<Author>authorList = null;
		
		Scanner scan = new Scanner(System.in);
		
		
	
			System.out.println("1. Add Author");
			System.out.println("2. View all Author");
			System.out.println("3. Delete Author");
			System.out.println("4. Search Author");
			System.out.println("5. Update Author");
			System.out.println("6. Exit");
			
			choice = Byte.parseByte(scan.nextLine());
			
			switch (choice){
			case 1:
				System.out.println("Enter first name : ");
				firstName = scan.next();
				System.out.println("Enter middle name : ");
				middleName = scan.next();
				System.out.println("Enter last name : ");
				lastName = scan.next();
				System.out.println("Enter phone number : ");
				phoneNo = scan.next();
				
				author = new Author();
				author.setFirstName(firstName);
				author.setMiddleName(middleName);
				author.setLastName(lastName);
				author.setPhoneNo(phoneNo);
				
				try {
					authorId =authorService.addAuthor(author);
				} catch (AuthorException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
				if(authorId!=0)
				{
					System.out.println("Author added with author id : "+authorId);
				}
				else{
					System.out.println("No author deleted");
				}
				
				
				
				break;
			
			
			
			case 2:
				try {
					authorList = authorService.displayAll();
				} catch (AuthorException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
					
					if(authorList!=null)
					{
						for (Author Author : authorList){
							System.out.println(Author);
						}
					}
					else{
						System.out.println("No author details available");
					}
				
				break;
				
			case 3:
				System.out.println("Enter authorId to delete author");
				authorId=scan.nextInt();
				try {
					author = authorService.deleteAuthor(authorId);
				} catch (AuthorException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if(author!=null)
				{
					System.out.println("Auhor deleted : " +author);
				}
				else{
					System.out.println("No author deleted");
				}
				break;
			case 4:
				System.out.println("Enter authorId to find author");
				authorId=scan.nextInt();
				try {
					author = authorService.findAuthor(authorId);
				} catch (AuthorException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if(author!=null)
				{
					System.out.println("Auhor details : " +author);
				}
				else{
					System.out.println("No author found");
				}
				
				break;
				
				
			case 5:
				System.out.println("Enter authorId to update phone number");
				authorId=scan.nextInt();
				scan.next();
				System.out.println("Enter phone number to update details");
				phoneNo=scan.nextLine();
				try {
					 isUpdated = authorService.updateAuthor(authorId,phoneNo);
				} catch (AuthorException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if(isUpdated)
				{
					System.out.println("Auhor details updated successfully");
				}
				else{
					System.out.println("No updation possible");
				}

				

				break;
			case 6:
				System.out.println("Exited successfully");
				System.exit(0);
				break;
			default:
				System.out.println("Invalid Input");

			}
			scan.close();
			
		}
	}
	
