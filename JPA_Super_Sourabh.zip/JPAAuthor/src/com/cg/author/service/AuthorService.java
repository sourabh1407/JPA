package com.cg.author.service;

import java.util.List;

import com.cg.author.dao.AuthorDAO;
import com.cg.author.dao.IAuthorDAO;
import com.cg.author.entities.Author;
import com.cg.author.exception.AuthorException;

public class AuthorService implements IAuthorService {
	
	IAuthorDAO adao = new AuthorDAO();
	
	@Override
	public int addAuthor(Author author) throws AuthorException {
		return adao.addAuthor(author);
	}

	@Override
	public Author deleteAuthor(int authorId) throws AuthorException {
		return adao.deleteAuthor(authorId);
	}

	@Override
	public Author findAuthor(int authorId) throws AuthorException {
		return adao.findAuthor(authorId);
	}

	@Override
	public List<Author> displayAll() throws AuthorException {
		return adao.displayAll();
	}

	@Override
	public boolean updateAuthor(int authorId,String phoneNo) throws AuthorException {
		return adao.updateAuthor(authorId,phoneNo);
	}

}
