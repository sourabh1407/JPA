package com.cg.author.service;

import java.util.List;

import com.cg.author.entities.Author;
import com.cg.author.exception.AuthorException;

public interface IAuthorService {
	
	public int addAuthor(Author author)throws AuthorException;
	
	public Author deleteAuthor(int authorId)throws AuthorException;
	
	public Author findAuthor(int authorId)throws AuthorException;
	
	public List<Author> displayAll()throws AuthorException;
	
	public boolean updateAuthor(int authorId,String phoneNo)throws AuthorException;
	
}	
